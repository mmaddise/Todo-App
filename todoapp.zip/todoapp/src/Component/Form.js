import { useState } from "react";
import styles from './form.module.css'
export default function Form({todos,setTodoList}){
   // const [todo,setTodo] = useState("");
   const [todo,setTodo] = useState({name:"",done: false});
    function handleAdd(e){
        e.preventDefault();
        setTodoList([...todos,todo]);
        setTodo({name:"",done:false});

    }
return (
    <form className={styles.todoform} onSubmit={(e) => handleAdd(e)}>
        <div className={styles.inputContainer}>
        <input className={styles.modernInput} onChange={(e) =>setTodo({name:e.target.value,done:false}) } type="text" value={todo.name}
            placeholder="Enter todo item..." />
            <br></br>
            <br></br>
            <button className={styles.modernButton} type="submit">Add</button>
        </div>
           
        </form>
)
}