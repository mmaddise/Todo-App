import { useState } from "react"
import Form from "./Form";
import ToDoList from "./ToDoList";
import Footer from "./Footer";

export default function Todo(){
    const [todos,setTodoList] = useState([]);
    const completedTodos = todos.filter((todo) => todo.done).length;
    const totalTodos= todos.length;
    return(
        <div>
       <Form todos = {todos} setTodoList = {setTodoList} />
        <ToDoList todos = {todos} setTodoList = {setTodoList} />
        <Footer completedTodos = {completedTodos} totalTodos={totalTodos} />
        </div>
    )
}