import styles from "./todoitem.module.css"
function TodoItem({item,todos,setTodoList}){
    function handleDelete(item){
        setTodoList(todos.filter((todo) => todo !== item));
        console.log();
    }
    function handleClick(name){
        const newArray = (todos.map((todo) => todo.name === name? {...todo,done:!todo.done} : todo));
        setTodoList(newArray);
       //console.log(todos);
    }
    const classLine = item.done ? styles.completed : "" ;
    // console.log({classLine});
  
return(
    <div className = {styles.item}>
        <div className= {styles.itemName}>
            <span className={classLine} onClick={() => handleClick(item.name)}>
                    {item.name}  
            </span>
        <span>
            <button className={styles.deleteButton} onClick={() =>handleDelete(item)}>x</button>
        </span>
        </div>
        <hr className ={styles.line}/>
    </div>
)

}

export default TodoItem